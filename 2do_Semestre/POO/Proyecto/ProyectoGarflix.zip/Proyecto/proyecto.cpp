//Juan Carlos Garfias Tovar, A01652138

//Este archivo abre el proyecto ya compilado para evitar errores por versiones de c++
//EL main y sus clases se encuentran en la carpeta classes
//Para evitar problemas compilar unicamente este codigo en Mac y linux
#include <cstdlib>
#include <iostream>
using namespace std;
int main(){
    system("./Classes/main");
    return 0;
}